/*  JFM1T2_Assignment1:

     Write a program to perform the below actions and print the result.
     1. Difference of 2 numbers (30 and 10)
     2. Product of 2 numbers (45 and 2)
     3. Division of 2 numbers (600 and 10)
     4. Increment and Decrement the number (15)
     5. Remainder of 2 numbers (14 and 5)
     Prompt the user input from the terminal.
*/

//import statements for java program to read inputs using Scanner class
import java.util.Scanner;

public class Operations {
  public static void main(String[] args) {

    Scanner s = new Scanner(System.in);
    System.out.println("Enter a1 number: ");
    int a1 = s.nextInt();
    System.out.println("Enter b1 number: ");
    int b1 = s.nextInt();
    System.out.println("1. Difference of 2 numbers is: " + (a1 - b1));
    
    System.out.println("Enter a2 number: ");
    int a2 = s.nextInt();
    System.out.println("Enter b2 number: ");
    int b2 = s.nextInt();
     System.out.println("2. Product of 2 numbers " + (a2 * b2));
    
    System.out.println("Enter a3 number: ");
    int a3 = s.nextInt();
    System.out.println("Enter b3 number: ");
    int b3 = s.nextInt();
     System.out.println("3. Division of 2 numbers " + (a3 / b3));
    
    System.out.println("Enter c number: ");
    int c = s.nextInt();
    System.out.println("4. Increment and Decrement of number " + (c++) + " and " + (c--));
    
    System.out.println("Enter a4 number: ");
    int a4 = s.nextInt();
    System.out.println("Enter b4 number: ");
    int b4 = s.nextInt();
    System.out.println("5. Remainder of 2 numbers " + (a4 % b4));

  }
  // main method

  /*
   * Use the scanner class to provide input at execution time using scanner object
   * Scanner sc=new Scanner(System.in);
   */

  /*
   * Take input from user
   * System.out.println("Enter first number: ");
   * int a=sc.nextInt();
   */

  // calculate difference,product,division,increment and remainder

  // print appropriate result for all operations

}